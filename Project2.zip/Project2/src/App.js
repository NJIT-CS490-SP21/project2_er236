import logo from './logo.svg';
import './App.css';
import {Board} from './Components/Board.js'

function App() {
  return (
    <div className="App">
      <Board/>
    </div>
  );
}

export default App;
